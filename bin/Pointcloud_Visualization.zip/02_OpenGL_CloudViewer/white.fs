#version 430 core

// output variables
out vec4 fragmentColor;  

void main()
{
    // fixed color
    fragmentColor = vec4(0.8f, 0.8f, 0.8f, 1.f);
}